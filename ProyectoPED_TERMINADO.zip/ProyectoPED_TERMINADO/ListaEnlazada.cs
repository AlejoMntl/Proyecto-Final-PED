﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoPED_1
{
    //clase que gestiona la lista enlazda de los libros
    internal class ListaEnlazada
    {
        private Libro primero;
        private int ultimoID;
        //Agregamos esto para la ruta del achivo del txt
		private string rutaArchivo;


		public ListaEnlazada()
        {
            primero = null;
            ultimoID = 0;

			//apunta hacia el archivo para recolectar los datos desde un inicio
			rutaArchivo = Path.Combine(Application.StartupPath, "libros.txt");

			// Cargar datos automáticamente al crear la instancia
			CargarDesdeArchivo();
		}

        public int GenerarID()
        {
            return ++ultimoID;
        }

        //metodo que añade un libro a la lista:
        public void AgregarLibro(string autor, string titulo,int añoPubli,
            bool disponible)
        {
			

			int nuevoID = GenerarID();
            Libro nuevoLibro = new Libro(nuevoID, autor, titulo, añoPubli, disponible);

            if(primero == null)
            {
                primero = nuevoLibro;
            }
            else
            {
                Libro actual = primero;
                while(actual.Siguiente != null)
                {
                    actual = actual.Siguiente;
                }
                actual.Siguiente = nuevoLibro;
            }
        }

        //metodo para buscar un libro
        public Libro BuscarLibro(int id,string titulo , string autor)
        {
            Libro actual = primero;
            while(actual != null)
            {
                if (actual.ID == id)
                    return actual;
                actual = actual.Siguiente;

                if (actual.Titulo == titulo)
                    return actual;
                actual = actual.Siguiente;

                if (actual.Autor == autor)
                    return actual;
                actual = actual.Siguiente;
            }
            return null;
        }
        // Buscar libro solo por ID
        public Libro BuscarLibro(int id)
        {
            Libro actual = primero;
            while (actual != null)
            {
                if (actual.ID == id)
                    return actual;

                actual = actual.Siguiente;
            }
            return null;
        }

        //Elimina un libro por ID:
        public bool EliminarLibro(int id)
        {
            if (primero == null)
                return false;
            if(primero.ID == id)
            {
                primero = primero.Siguiente;
                return true;
            }

            Libro actual = primero;
            while (actual.Siguiente != null)
            {
                if(actual.Siguiente.ID == id)
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        // Eliminar un libro por título:
        public bool EliminarLibroPorTitulo(string titulo)
        {
            if (primero == null)
                return false;

            if (primero.Titulo == titulo)
            {
                primero = primero.Siguiente;
                return true;
            }

            Libro actual = primero;
            while (actual.Siguiente != null)
            {
                if (actual.Siguiente.Titulo == titulo)
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        // Eliminar un libro por autor:
        public bool EliminarLibroPorAutor(string autor)
        {
            if (primero == null)
                return false;

            if (primero.Autor == autor)
            {
                primero = primero.Siguiente;
                return true;
            }

            Libro actual = primero;
            while (actual.Siguiente != null)
            {
                if (actual.Siguiente.Autor == autor)
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        public List<LibroDTO> ObtenerLibros()
        {
            List<LibroDTO> libros = new List<LibroDTO>();
            Libro actual = primero;

            while(actual != null)
            {
                libros.Add(new LibroDTO
                {
                    ID = actual.ID,
                    Autor = actual.Autor,
                    Titulo = actual.Titulo,
                    AñoPublicacion = actual.añoPublicacion,                   
                    Disponibilidad = actual.Disponibilidad,
                });

                actual = actual.Siguiente;
            }
            return libros;
        }
		// Prueba para guardar txt
		public void GuardarEnArchivo()
		{
			// Ruta dentro del proyecto: \bin\Debug\libros.txt
			string ruta = Path.Combine(Application.StartupPath, "libros.txt");

			using (StreamWriter sw = new StreamWriter(ruta, false)) 
			{
				Libro actual = primero;
				while (actual != null)
				{
					sw.WriteLine($"{actual.ID}|{actual.Autor}|{actual.Titulo}|{actual.añoPublicacion}|{actual.Disponibilidad}");
					actual = actual.Siguiente;
				}
			}
		}

        //Cambio de CargarDesdeArchivo
		public void CargarDesdeArchivo()
		{
			if (File.Exists(rutaArchivo))
			{
				// Limpiar lista actual
				primero = null;
				ultimoID = 0;

				foreach (string linea in File.ReadAllLines(rutaArchivo))
				{
					string[] datos = linea.Split('|');
					if (datos.Length == 5)
					{
						int id = int.Parse(datos[0]);
						string autor = datos[1];
						string titulo = datos[2];
						int año = int.Parse(datos[3]);
						bool disponible = bool.Parse(datos[4]);

						// Agregar libro directamente (sin usar AgregarLibro para evitar regenerar IDs)
						Libro nuevo = new Libro(id, autor, titulo, año, disponible);

						if (primero == null)
						{
							primero = nuevo;
						}
						else
						{
							Libro actual = primero;
							while (actual.Siguiente != null)
							{
								actual = actual.Siguiente;
							}
							actual.Siguiente = nuevo;
						}

						// Actualizar el último ID
						if (id > ultimoID)
						{
							ultimoID = id;
						}
					}
				}
			}
		}
		//PRUEBA DE ELIMINAR LIBRO DEL TXT 
		//TENER CUIDADO POR QUE HAY OTRA FUNCION QUE SE LLAMA ELIMINAR LIBRO
		public bool EliminarLibroTXT(int id)
		{
			bool eliminado = false;

			// Eliminación en la lista enlazada
			if (primero == null)
				return false;

			if (primero.ID == id)
			{
				primero = primero.Siguiente;
				eliminado = true;
			}
			else
			{
				Libro actual = primero;
				while (actual.Siguiente != null)
				{
					if (actual.Siguiente.ID == id)
					{
						actual.Siguiente = actual.Siguiente.Siguiente;
						eliminado = true;
						break;
					}
					actual = actual.Siguiente;
				}
			}

			// Si se eliminó de la lista, actualizar el archivo
			if (eliminado)
			{
				GuardarEnArchivo(); // Esto sobrescribirá el archivo con la lista actualizada
			}

			return eliminado;
		}
		//Cree otra funcion para elimiar por autor pero ahora tmb lo borra en el txt
		public bool EliminarLibrosPorAutorTXT(string autor)
		{
			bool eliminados = false;
			Libro actual = primero;
			Libro anterior = null;

			while (actual != null)
			{
				if (actual.Autor.Equals(autor, StringComparison.OrdinalIgnoreCase))
				{
					if (anterior == null)
					{
						primero = actual.Siguiente;
					}
					else
					{
						anterior.Siguiente = actual.Siguiente;
					}
					eliminados = true;
				}
				else
				{
					anterior = actual;
				}
				actual = actual.Siguiente;
			}

			if (eliminados)
			{
				GuardarEnArchivo();
			}

			return eliminados;
		}
		//Cree otra funcion para elimiar por año pero ahora tmb lo borra en el txt

		public bool EliminarLibrosPorAñoTXT(int año)
		{
			bool eliminados = false;
			Libro actual = primero;
			Libro anterior = null;

			while (actual != null)
			{
				if (actual.añoPublicacion == año)
				{
					if (anterior == null)
					{
						primero = actual.Siguiente;
					}
					else
					{
						anterior.Siguiente = actual.Siguiente;
					}
					eliminados = true;
				}
				else
				{
					anterior = actual;
				}
				actual = actual.Siguiente;
			}

			if (eliminados)
			{
				GuardarEnArchivo();
			}

			return eliminados;
		}

	
	}


	//no tocar nada a partir de aca.
}
