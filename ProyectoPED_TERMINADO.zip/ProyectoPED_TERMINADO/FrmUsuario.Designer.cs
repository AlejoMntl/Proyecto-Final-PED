﻿namespace ProyectoPED_1
{
	partial class FrmUsuario
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUsuario));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.txtNombreUsuario = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.lblUsuario = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.cmbPrioridad = new MetroFramework.Controls.MetroComboBox();
            this.btnReservar = new MetroFramework.Controls.MetroButton();
            this.dtpFechaFin = new MetroFramework.Controls.MetroDateTime();
            this.dtpFechaIni = new MetroFramework.Controls.MetroDateTime();
            this.cmbLibros = new MetroFramework.Controls.MetroComboBox();
            this.DGLibrosDisponibles = new MetroFramework.Controls.MetroGrid();
            this.btnBuscaLibro = new MetroFramework.Controls.MetroButton();
            this.txtBuscarLibro = new MetroFramework.Controls.MetroTextBox();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCancelar = new MetroFramework.Controls.MetroButton();
            this.dgvReservas = new MetroFramework.Controls.MetroGrid();
            this.btnRegresar = new MetroFramework.Controls.MetroButton();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGLibrosDisponibles)).BeginInit();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservas)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Location = new System.Drawing.Point(45, 86);
            this.metroTabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(1368, 513);
            this.metroTabControl1.TabIndex = 14;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.BackColor = System.Drawing.Color.Chocolate;
            this.metroTabPage1.Controls.Add(this.metroLabel7);
            this.metroTabPage1.Controls.Add(this.txtNombreUsuario);
            this.metroTabPage1.Controls.Add(this.metroLabel6);
            this.metroTabPage1.Controls.Add(this.metroLabel5);
            this.metroTabPage1.Controls.Add(this.lblUsuario);
            this.metroTabPage1.Controls.Add(this.metroLabel2);
            this.metroTabPage1.Controls.Add(this.metroLabel3);
            this.metroTabPage1.Controls.Add(this.metroLabel4);
            this.metroTabPage1.Controls.Add(this.cmbPrioridad);
            this.metroTabPage1.Controls.Add(this.btnReservar);
            this.metroTabPage1.Controls.Add(this.dtpFechaFin);
            this.metroTabPage1.Controls.Add(this.dtpFechaIni);
            this.metroTabPage1.Controls.Add(this.cmbLibros);
            this.metroTabPage1.Controls.Add(this.DGLibrosDisponibles);
            this.metroTabPage1.Controls.Add(this.btnBuscaLibro);
            this.metroTabPage1.Controls.Add(this.txtBuscarLibro);
            this.metroTabPage1.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 12;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(1360, 471);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "LIBROS DISPONIBLES";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 13;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(49, 350);
            this.metroLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(72, 25);
            this.metroLabel7.TabIndex = 50;
            this.metroLabel7.Text = "HASTA";
            this.metroLabel7.UseStyleColors = true;
            // 
            // txtNombreUsuario
            // 
            // 
            // 
            // 
            this.txtNombreUsuario.CustomButton.Image = null;
            this.txtNombreUsuario.CustomButton.Location = new System.Drawing.Point(180, 2);
            this.txtNombreUsuario.CustomButton.Margin = new System.Windows.Forms.Padding(5);
            this.txtNombreUsuario.CustomButton.Name = "";
            this.txtNombreUsuario.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtNombreUsuario.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtNombreUsuario.CustomButton.TabIndex = 1;
            this.txtNombreUsuario.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtNombreUsuario.CustomButton.UseSelectable = true;
            this.txtNombreUsuario.CustomButton.Visible = false;
            this.txtNombreUsuario.Lines = new string[0];
            this.txtNombreUsuario.Location = new System.Drawing.Point(321, 82);
            this.txtNombreUsuario.Margin = new System.Windows.Forms.Padding(4);
            this.txtNombreUsuario.MaxLength = 32767;
            this.txtNombreUsuario.Name = "txtNombreUsuario";
            this.txtNombreUsuario.PasswordChar = '\0';
            this.txtNombreUsuario.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNombreUsuario.SelectedText = "";
            this.txtNombreUsuario.SelectionLength = 0;
            this.txtNombreUsuario.SelectionStart = 0;
            this.txtNombreUsuario.ShortcutsEnabled = true;
            this.txtNombreUsuario.Size = new System.Drawing.Size(208, 30);
            this.txtNombreUsuario.TabIndex = 48;
            this.txtNombreUsuario.UseSelectable = true;
            this.txtNombreUsuario.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtNombreUsuario.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.Location = new System.Drawing.Point(49, 293);
            this.metroLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(68, 25);
            this.metroLabel6.TabIndex = 49;
            this.metroLabel6.Text = "DESDE";
            this.metroLabel6.UseStyleColors = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(117, 241);
            this.metroLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(263, 25);
            this.metroLabel5.TabIndex = 48;
            this.metroLabel5.Text = "INGRESA FECHA DE RESERVA";
            this.metroLabel5.UseStyleColors = true;
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.BackColor = System.Drawing.Color.Chartreuse;
            this.lblUsuario.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblUsuario.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblUsuario.Location = new System.Drawing.Point(33, 87);
            this.lblUsuario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(91, 25);
            this.lblUsuario.TabIndex = 46;
            this.lblUsuario.Text = "NOMBRE";
            this.lblUsuario.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(32, 30);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(141, 25);
            this.metroLabel2.TabIndex = 45;
            this.metroLabel2.Text = "BUSCAR LIBRO";
            this.metroLabel2.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(33, 132);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(195, 25);
            this.metroLabel3.TabIndex = 46;
            this.metroLabel3.Text = "LIBROS DISPONIBLES";
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(33, 182);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(168, 25);
            this.metroLabel4.TabIndex = 47;
            this.metroLabel4.Text = "TIPO DE USUARIO";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel4.UseStyleColors = true;
            // 
            // cmbPrioridad
            // 
            this.cmbPrioridad.FormattingEnabled = true;
            this.cmbPrioridad.ItemHeight = 24;
            this.cmbPrioridad.Items.AddRange(new object[] {
            "Personal Academico Profesor",
            "Estudiante Posgrado",
            "Estudiante Pregrado"});
            this.cmbPrioridad.Location = new System.Drawing.Point(321, 182);
            this.cmbPrioridad.Margin = new System.Windows.Forms.Padding(4);
            this.cmbPrioridad.Name = "cmbPrioridad";
            this.cmbPrioridad.Size = new System.Drawing.Size(207, 30);
            this.cmbPrioridad.TabIndex = 41;
            this.cmbPrioridad.UseSelectable = true;
            this.cmbPrioridad.SelectedIndexChanged += new System.EventHandler(this.cmbPrioridad_SelectedIndexChanged_1);
            // 
            // btnReservar
            // 
            this.btnReservar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnReservar.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnReservar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnReservar.Location = new System.Drawing.Point(117, 407);
            this.btnReservar.Margin = new System.Windows.Forms.Padding(4);
            this.btnReservar.Name = "btnReservar";
            this.btnReservar.Size = new System.Drawing.Size(253, 47);
            this.btnReservar.TabIndex = 39;
            this.btnReservar.Text = "RESERVAR LIBRO";
            this.btnReservar.UseCustomBackColor = true;
            this.btnReservar.UseCustomForeColor = true;
            this.btnReservar.UseMnemonic = false;
            this.btnReservar.UseSelectable = true;
            this.btnReservar.UseStyleColors = true;
            this.btnReservar.Click += new System.EventHandler(this.btnReservar_Click);
            // 
            // dtpFechaFin
            // 
            this.dtpFechaFin.Location = new System.Drawing.Point(149, 345);
            this.dtpFechaFin.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFechaFin.MinimumSize = new System.Drawing.Size(0, 30);
            this.dtpFechaFin.Name = "dtpFechaFin";
            this.dtpFechaFin.Size = new System.Drawing.Size(265, 30);
            this.dtpFechaFin.TabIndex = 38;
            // 
            // dtpFechaIni
            // 
            this.dtpFechaIni.Location = new System.Drawing.Point(149, 288);
            this.dtpFechaIni.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFechaIni.MinimumSize = new System.Drawing.Size(0, 30);
            this.dtpFechaIni.Name = "dtpFechaIni";
            this.dtpFechaIni.Size = new System.Drawing.Size(265, 30);
            this.dtpFechaIni.TabIndex = 37;
            // 
            // cmbLibros
            // 
            this.cmbLibros.FormattingEnabled = true;
            this.cmbLibros.ItemHeight = 24;
            this.cmbLibros.Location = new System.Drawing.Point(321, 127);
            this.cmbLibros.Margin = new System.Windows.Forms.Padding(4);
            this.cmbLibros.Name = "cmbLibros";
            this.cmbLibros.Size = new System.Drawing.Size(207, 30);
            this.cmbLibros.TabIndex = 33;
            this.cmbLibros.UseSelectable = true;
            this.cmbLibros.SelectedIndexChanged += new System.EventHandler(this.cmbLibros_SelectedIndexChanged);
            // 
            // DGLibrosDisponibles
            // 
            this.DGLibrosDisponibles.AllowUserToResizeRows = false;
            this.DGLibrosDisponibles.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGLibrosDisponibles.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.DGLibrosDisponibles.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGLibrosDisponibles.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGLibrosDisponibles.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.DGLibrosDisponibles.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGLibrosDisponibles.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.DGLibrosDisponibles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGLibrosDisponibles.DefaultCellStyle = dataGridViewCellStyle8;
            this.DGLibrosDisponibles.EnableHeadersVisualStyles = false;
            this.DGLibrosDisponibles.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.DGLibrosDisponibles.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.DGLibrosDisponibles.Location = new System.Drawing.Point(551, 76);
            this.DGLibrosDisponibles.Margin = new System.Windows.Forms.Padding(4);
            this.DGLibrosDisponibles.Name = "DGLibrosDisponibles";
            this.DGLibrosDisponibles.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGLibrosDisponibles.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.DGLibrosDisponibles.RowHeadersWidth = 51;
            this.DGLibrosDisponibles.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.DGLibrosDisponibles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGLibrosDisponibles.Size = new System.Drawing.Size(740, 378);
            this.DGLibrosDisponibles.TabIndex = 24;
            this.DGLibrosDisponibles.UseCustomBackColor = true;
            this.DGLibrosDisponibles.UseCustomForeColor = true;
            this.DGLibrosDisponibles.UseStyleColors = true;
            this.DGLibrosDisponibles.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.DGLibrosDisponibles_RowPrePaint);
            // 
            // btnBuscaLibro
            // 
            this.btnBuscaLibro.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBuscaLibro.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnBuscaLibro.ForeColor = System.Drawing.SystemColors.Control;
            this.btnBuscaLibro.Location = new System.Drawing.Point(839, 20);
            this.btnBuscaLibro.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscaLibro.Name = "btnBuscaLibro";
            this.btnBuscaLibro.Size = new System.Drawing.Size(145, 41);
            this.btnBuscaLibro.TabIndex = 32;
            this.btnBuscaLibro.Text = "BUSCAR";
            this.btnBuscaLibro.UseCustomBackColor = true;
            this.btnBuscaLibro.UseCustomForeColor = true;
            this.btnBuscaLibro.UseMnemonic = false;
            this.btnBuscaLibro.UseSelectable = true;
            this.btnBuscaLibro.UseStyleColors = true;
            this.btnBuscaLibro.Click += new System.EventHandler(this.btnBuscaLibro_Click);
            // 
            // txtBuscarLibro
            // 
            // 
            // 
            // 
            this.txtBuscarLibro.CustomButton.Image = null;
            this.txtBuscarLibro.CustomButton.Location = new System.Drawing.Point(577, 1);
            this.txtBuscarLibro.CustomButton.Margin = new System.Windows.Forms.Padding(5);
            this.txtBuscarLibro.CustomButton.Name = "";
            this.txtBuscarLibro.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtBuscarLibro.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBuscarLibro.CustomButton.TabIndex = 1;
            this.txtBuscarLibro.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBuscarLibro.CustomButton.UseSelectable = true;
            this.txtBuscarLibro.CustomButton.Visible = false;
            this.txtBuscarLibro.Lines = new string[0];
            this.txtBuscarLibro.Location = new System.Drawing.Point(228, 33);
            this.txtBuscarLibro.Margin = new System.Windows.Forms.Padding(4);
            this.txtBuscarLibro.MaxLength = 32767;
            this.txtBuscarLibro.Name = "txtBuscarLibro";
            this.txtBuscarLibro.PasswordChar = '\0';
            this.txtBuscarLibro.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBuscarLibro.SelectedText = "";
            this.txtBuscarLibro.SelectionLength = 0;
            this.txtBuscarLibro.SelectionStart = 0;
            this.txtBuscarLibro.ShortcutsEnabled = true;
            this.txtBuscarLibro.Size = new System.Drawing.Size(603, 27);
            this.txtBuscarLibro.TabIndex = 3;
            this.txtBuscarLibro.UseSelectable = true;
            this.txtBuscarLibro.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBuscarLibro.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroLabel1);
            this.metroTabPage2.Controls.Add(this.pictureBox1);
            this.metroTabPage2.Controls.Add(this.btnCancelar);
            this.metroTabPage2.Controls.Add(this.dgvReservas);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 12;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(1360, 471);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "RESERVAS";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 13;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(0, 37);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(228, 25);
            this.metroLabel1.TabIndex = 19;
            this.metroLabel1.Text = "RESERVAS REGISTRADAS";
            this.metroLabel1.UseStyleColors = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(999, 87);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(337, 279);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.Firebrick;
            this.btnCancelar.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnCancelar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCancelar.Location = new System.Drawing.Point(-5, 416);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(228, 50);
            this.btnCancelar.TabIndex = 45;
            this.btnCancelar.Text = "CANCELAR RESERVA";
            this.btnCancelar.UseCustomBackColor = true;
            this.btnCancelar.UseCustomForeColor = true;
            this.btnCancelar.UseMnemonic = false;
            this.btnCancelar.UseSelectable = true;
            this.btnCancelar.UseStyleColors = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // dgvReservas
            // 
            this.dgvReservas.AllowUserToResizeRows = false;
            this.dgvReservas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvReservas.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dgvReservas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvReservas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvReservas.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dgvReservas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReservas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvReservas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvReservas.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvReservas.EnableHeadersVisualStyles = false;
            this.dgvReservas.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvReservas.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvReservas.Location = new System.Drawing.Point(-5, 87);
            this.dgvReservas.Margin = new System.Windows.Forms.Padding(4);
            this.dgvReservas.Name = "dgvReservas";
            this.dgvReservas.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReservas.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvReservas.RowHeadersWidth = 51;
            this.dgvReservas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvReservas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvReservas.Size = new System.Drawing.Size(996, 279);
            this.dgvReservas.TabIndex = 25;
            this.dgvReservas.UseCustomBackColor = true;
            this.dgvReservas.UseCustomForeColor = true;
            this.dgvReservas.UseStyleColors = true;
            // 
            // btnRegresar
            // 
            this.btnRegresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnRegresar.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btnRegresar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRegresar.Location = new System.Drawing.Point(1175, 607);
            this.btnRegresar.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(167, 46);
            this.btnRegresar.TabIndex = 18;
            this.btnRegresar.Text = "SALIR";
            this.btnRegresar.UseCustomBackColor = true;
            this.btnRegresar.UseCustomForeColor = true;
            this.btnRegresar.UseSelectable = true;
            this.btnRegresar.UseStyleColors = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // FrmUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1464, 661);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.metroTabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmUsuario";
            this.Padding = new System.Windows.Forms.Padding(20, 74, 20, 20);
            this.Text = "FrmUsuario";
            this.Load += new System.EventHandler(this.FrmUsuario_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGLibrosDisponibles)).EndInit();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservas)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion
		private MetroFramework.Controls.MetroTabControl metroTabControl1;
		private MetroFramework.Controls.MetroTabPage metroTabPage1;
		private MetroFramework.Controls.MetroTextBox txtBuscarLibro;
		private MetroFramework.Controls.MetroTabPage metroTabPage2;
		private MetroFramework.Controls.MetroButton btnBuscaLibro;
		private MetroFramework.Controls.MetroGrid DGLibrosDisponibles;
		private MetroFramework.Controls.MetroComboBox cmbLibros;
		private MetroFramework.Controls.MetroDateTime dtpFechaFin;
		private MetroFramework.Controls.MetroDateTime dtpFechaIni;
		private MetroFramework.Controls.MetroButton btnReservar;
		private MetroFramework.Controls.MetroGrid dgvReservas;
		private MetroFramework.Controls.MetroComboBox cmbPrioridad;
		private MetroFramework.Controls.MetroButton btnRegresar;
		private MetroFramework.Controls.MetroButton btnCancelar;
		private System.Windows.Forms.PictureBox pictureBox1;
		private MetroFramework.Controls.MetroLabel metroLabel1;
		private MetroFramework.Controls.MetroLabel metroLabel7;
		private MetroFramework.Controls.MetroTextBox txtNombreUsuario;
		private MetroFramework.Controls.MetroLabel metroLabel6;
		private MetroFramework.Controls.MetroLabel metroLabel5;
		private MetroFramework.Controls.MetroLabel lblUsuario;
		private MetroFramework.Controls.MetroLabel metroLabel2;
		private MetroFramework.Controls.MetroLabel metroLabel3;
		private MetroFramework.Controls.MetroLabel metroLabel4;
	}
}