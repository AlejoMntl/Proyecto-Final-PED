﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ProyectoPED_1.Reserva;
using static System.Collections.Specialized.BitVector32;

namespace ProyectoPED_1
{
    public partial class FrmUsuario : MetroFramework.Forms.MetroForm
    {
		//referencia al formulario principal para regresar al mismo
		private FrmMenu menu;
		
		private FrmGestionLibros gestion;
		private ColaPrioridad colaReservas;
		private ListaEnlazada enlazada;
		private ArbolBinarioLibros arbolLibros;
		private string usuarioActual;
		private string tipoUserActual;
		

		public FrmUsuario(FrmMenu Menu, string nombreuser, string tipouser,
			FrmGestionLibros Gestion)
		{
			InitializeComponent();         
            menu = Menu;
            gestion = Gestion;
            usuarioActual = nombreuser;
			tipoUserActual = tipouser;

			//Inicializar estructuras
			enlazada = gestion.ObtenerListaEnlazada();
			arbolLibros = new ArbolBinarioLibros();
            colaReservas = new ColaPrioridad();
           
			
			//Cargar datos
			enlazada.CargarDesdeArchivo();
			colaReservas.CargarDesdeArchivo();

			
			//se construye el arbol
            foreach (var libroDTO in enlazada.ObtenerLibros())
			{
				Libro libro = new Libro(
					libroDTO.ID,
					libroDTO.Autor,
					libroDTO.Titulo,
					libroDTO.AñoPublicacion,
					libroDTO.Disponibilidad
				);
				arbolLibros.InsertarID(libro);
			}

			//Configurar controles
			ConfigurarControles();
			ConfigurarFechas();
			ConfigurarDGV();
			ConfigurarDVGReservas();

			//Mostramos datos
			MostrarLibrosDisponibles();
			MostrarReservasEnGrid();

			//Carga nombre del usuario actual:
			txtNombreUsuario.Text = usuarioActual;
		}
	
		private void MostrarLibrosDisponibles()
		{
			try
			{
                var librosDisponibles = enlazada.ObtenerLibros()
                .Where(l => l.Disponibilidad)
                .ToList();

				DGLibrosDisponibles.DataSource = null;
				DGLibrosDisponibles.DataSource = librosDisponibles;

				CargarComboBoxLibros();
            }
			catch(Exception ex)
			{
				MessageBox.Show($"Error al cargar libros: {ex.Message}", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	
		private void MostrarResultado(List<Libro> libros)
		{
            var librosDTO = libros.Select(l => new LibroDTO
            {
                ID = l.ID,
                Titulo = l.Titulo,
                Autor = l.Autor,
                AñoPublicacion = l.añoPublicacion,
                Disponibilidad = l.Disponibilidad
            }).ToList();

            DGLibrosDisponibles.DataSource = librosDTO;
            CargarComboBoxLibros();
        }

		//para las reservas 
		private void MostrarReservasEnGrid()
		{
            var reservas = colaReservas.ObtenerReservas();

            foreach (var reserva in reservas)
            {
                reserva.Prioridad = $"{reserva.Prioridad} ({reserva.TipoUsuario})";

                if (string.IsNullOrEmpty(reserva.TituloLibro))
                {
                    var libro = enlazada.ObtenerLibros().FirstOrDefault(l => l.ID == reserva.LibroID);
                    reserva.TituloLibro = libro?.Titulo ?? $"Libro ID: {reserva.LibroID}";
                }
            }

            dgvReservas.DataSource = reservas;
        }

		private void ConfigurarControles()
		{
			cmbPrioridad.Items.AddRange(Enum.GetNames(typeof(Reserva.TipoPrioridad)));

			if (tipoUserActual == "Profesor" || tipoUserActual == "Personal Academico")
			{
				cmbPrioridad.SelectedIndex = 0;
				cmbPrioridad.Enabled = true;
			}
			else if (tipoUserActual == "Estudiante Posgrado")
			{
				cmbPrioridad.SelectedIndex = 1;
				cmbPrioridad.Enabled = true;
			}
			else
			{
				cmbPrioridad.SelectedIndex = 2;
				cmbPrioridad.Enabled = true;
			}

			lblUsuario.Text = $"Usuario: {usuarioActual} ({tipoUserActual})";
		}

		//Data grid para reserva 2da pag
		private void ConfigurarDVGReservas()
        {
            dgvReservas.AutoGenerateColumns = false;
            dgvReservas.Columns.Clear();

            var columns = new[]
            {
              new DataGridViewTextBoxColumn { Name = "ID", HeaderText = "ID", DataPropertyName = "ID", Width = 50 },
              new DataGridViewTextBoxColumn { Name = "LibroID", HeaderText = "ID Libro", DataPropertyName = "LibroID", Width = 70 },
              new DataGridViewTextBoxColumn { Name = "TituloLibro", HeaderText = "Título Libro", DataPropertyName = "TituloLibro", Width = 150 },
              new DataGridViewTextBoxColumn { Name = "NombreUsuario", HeaderText = "Usuario", DataPropertyName = "NombreUsuario", Width = 70 },
              new DataGridViewTextBoxColumn { Name = "TipoUsuario", HeaderText = "Tipo Usuario", DataPropertyName = "TipoUsuario", Width = 70 },
              new DataGridViewTextBoxColumn { Name = "Prioridad", HeaderText = "Prioridad", DataPropertyName = "Prioridad", Width = 100 },
              new DataGridViewTextBoxColumn { Name = "FechaSolicitud", HeaderText = "Fecha", DataPropertyName = "FechaFormateada", Width = 100 },
              new DataGridViewTextBoxColumn { Name = "TiempoEspera", HeaderText = "Tiempo Espera", DataPropertyName = "TiempoEspera", Width = 70 },
			 
            };

            dgvReservas.Columns.AddRange(columns);

        }      
     
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            menu.Show();//muestra el menu 
            this.Close();//cierra el form actual
        }

        private void dgvReservas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //DataGridView para la primera pestaña:
        private void ConfigurarDGV()
        {
            DGLibrosDisponibles.AutoGenerateColumns = false;
            DGLibrosDisponibles.Columns.Clear();

            DGLibrosDisponibles.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ID",
                HeaderText = "ID",
                DataPropertyName = "ID",
                Width = 50
            });

            DGLibrosDisponibles.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Titulo",
                HeaderText = "Título",
                DataPropertyName = "Titulo",
                Width = 150
            });

            DGLibrosDisponibles.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Autor",
                HeaderText = "Autor",
                DataPropertyName = "Autor",
                Width = 150
            });

            DGLibrosDisponibles.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "AñoPublicacion",
                HeaderText = "Año Publicación",
                DataPropertyName = "AñoPublicacion"
            });

            DGLibrosDisponibles.Columns.Add(new DataGridViewCheckBoxColumn
            {
                Name = "Disponibilidad",
                HeaderText = "Disponible",
                DataPropertyName = "Disponibilidad"
            });

        }

        //Funcion para buscarLibro por titulo atravez del arbol binario
		private void btnBuscaLibro_Click(object sender, EventArgs e)
		{
			try
			{
				string titulo = txtBuscarLibro.Text.Trim();

				if (string.IsNullOrWhiteSpace(titulo))
				{
					MessageBox.Show("Por favor, ingrese un título válido", "Título vacío",
						MessageBoxButtons.OK, MessageBoxIcon.Warning);
					txtBuscarLibro.Focus();
					return;
				}

				List<Libro> librosEncontrados = arbolLibros.BuscarPorTitulo(titulo);

				if (librosEncontrados.Count > 0)
				{
					MostrarResultado(librosEncontrados);
					MessageBox.Show($"{librosEncontrados.Count} libro(s) encontrado(s)", "Éxito",
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else
				{
					DGLibrosDisponibles.DataSource = null;
					MessageBox.Show($"No se encontraron libros con el título: {titulo}", "Libro no encontrado",
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error al buscar libro: {ex.Message}", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		//Configuracion de comboBox
		private void CargarComboBoxLibros()
		{
			//cmbLibros.Items.Clear();
			cmbLibros.DisplayMember = "Titulo"; // Propiedad a mostrar
			cmbLibros.ValueMember = "ID";       // Valor asociado

			if (DGLibrosDisponibles.DataSource is List<LibroDTO> libros)
			{
				// Filtrar solo libros disponibles
				var librosDisponibles = libros.Where(l => l.Disponibilidad).ToList();
				cmbLibros.DataSource = librosDisponibles;

				if (cmbLibros.Items.Count > 0)
					cmbLibros.SelectedIndex = 0;
				else
					MessageBox.Show("No hay libros disponibles para reservar", "Información",
								  MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

		private void cmbLibros_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		//Configuracion de los dataTime pickkr
		private void ConfigurarFechas()
		{
			// 1. Configuración básica al cargar el formulario
			DateTime hoy = DateTime.Today;

			// DateTimePicker de inicio
			dtpFechaIni.MinDate = hoy;
			dtpFechaIni.MaxDate = hoy.AddDays(15);
			dtpFechaIni.Value = hoy;

			// DateTimePicker de fin
			dtpFechaFin.MinDate = hoy.AddDays(1); // No permite seleccionar el mismo día
			dtpFechaFin.MaxDate = hoy.AddDays(15);
			dtpFechaFin.Value = hoy.AddDays(1);
		}

		// Validación cuando cambian las fechas
		private void ValidarFechas(object sender, EventArgs e)
		{
			// Simple validación No permitir fechas pasadas
			if (dtpFechaIni.Value < DateTime.Today)
			{
				dtpFechaIni.Value = DateTime.Today;
			}

			// Simple validación  Máximo 15 días
			if (dtpFechaFin.Value > DateTime.Today.AddDays(15))
			{
				dtpFechaFin.Value = DateTime.Today.AddDays(15);
			}

			// Asegurar que fecha fin sea mayor que fecha inicio
			if (dtpFechaFin.Value <= dtpFechaIni.Value)
			{
				dtpFechaFin.Value = dtpFechaIni.Value.AddDays(1);
			}
		}

		// Al hacer clic en reservar
		private void btnReservar_Click(object sender, EventArgs e)
		{
			try
			{
				//valida el nombre del usuario
				if(string.IsNullOrEmpty(txtNombreUsuario.Text))
				{
					MessageBox.Show("Por favor ingrese su nombre completo", "Datos Incompletos",
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					txtNombreUsuario.Focus();
					return;
				}

				//valida la seleccion del libro
				if (cmbLibros.SelectedItem == null)
				{
					MessageBox.Show("Seleccione un libro", "Advertencia",
						MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}

				//validacion de fechas
				if (dtpFechaFin.Value <= dtpFechaIni.Value)
				{
					MessageBox.Show("La fecha final debe ser posterior a la inicial", "Validación",
						MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
						
				LibroDTO libroSeleccionado = (LibroDTO)cmbLibros.SelectedItem;

				//verifica la disponibilidad del libro
                if (!libroSeleccionado.Disponibilidad)
                {
                    MessageBox.Show("El libro seleccionado ya no está disponible", "Libro no disponible",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    MostrarLibrosDisponibles(); // Refrescar lista
                    return;
                }


                // Crear reserva
                colaReservas.AgregarReserva(
					libroSeleccionado.ID,
					txtNombreUsuario.Text.Trim(),
					(TipoPrioridad)cmbPrioridad.SelectedIndex,
					tipoUserActual,
					dtpFechaIni.Value,
					dtpFechaFin.Value
				);

				
				

				// Guardar y actualizar
				colaReservas.GuardarEnArchivo();
				enlazada.GuardarEnArchivo();

				MostrarLibrosDisponibles();
				MostrarReservasEnGrid();

				//MostrarReservasEnGrid();

				MessageBox.Show($"Reserva realizada para {txtNombreUsuario.Text}", "Éxito",
					MessageBoxButtons.OK, MessageBoxIcon.Information);

				txtNombreUsuario.Text = "";
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error al reservar: {ex.Message}", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

        private void FrmUsuario_Load(object sender, EventArgs e)
        {
			if(!string.IsNullOrEmpty(usuarioActual))
			{
				txtNombreUsuario.Text = usuarioActual;
			}
        }

        private void cmbPrioridad_SelectedIndexChanged(object sender, EventArgs e)
        {
			
        }		
        private void DGLibrosDisponibles_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {			
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
			if(dgvReservas.CurrentRow == null ||
				dgvReservas.CurrentRow.DataBoundItem == null)
			{
				MessageBox.Show("Seleccione una reserva para eliminar", "Advertencia",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			try
			{
				var reservaSeleccionada = (ReservaDTO)dgvReservas.CurrentRow.
					DataBoundItem;

				//confirmar eliminacion:
				var confirma = MessageBox.Show(
					$"¿Esta seguro/a de eliminar la reserva del libro '{reservaSeleccionada.TituloLibro}'?",
					"Confirmar Eliminacion", MessageBoxButtons.YesNo,
					MessageBoxIcon.Question);

				if(confirma == DialogResult.Yes)
				{
					bool eliminado = colaReservas.EliminarReserva(reservaSeleccionada.ID);

					if(eliminado)
					{
                        var libro = enlazada.ObtenerLibros().FirstOrDefault(l => l.ID == reservaSeleccionada.LibroID);
                        if (libro != null)
                        {
                            libro.Disponibilidad = true;
                            enlazada.GuardarEnArchivo();
                        }

						//actualiza la interfaz
						colaReservas.GuardarEnArchivo();
						MostrarLibrosDisponibles();
						MostrarReservasEnGrid();

						MessageBox.Show("Reserva Eliminada exitosamente", "Exito",
							MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
					else
					{
						MessageBox.Show("No se pudo eliminar la reserva", "Error",
							MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show($"Error al eliminar reserva: {ex.Message}", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

        }

		private void htmlLabel8_Click(object sender, EventArgs e)
		{

		}

        private void cmbPrioridad_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    } //Fin del codigo en Form, NO tocar
	
}
