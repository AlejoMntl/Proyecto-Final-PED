﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPED_1
{
    internal class Reserva
    {
        public int ID { get; set; }
        public int LibroID { get; set; }
        public string NombreUsuario { get; set; }
        public TipoPrioridad Prioridad { get; set; }
        public DateTime FechaSolicitud { get; set; }    
        public string TipoUsuario { get; set; }
        public Reserva Siguiente { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }

        public Reserva(int id, int libroID, string nombreuser, TipoPrioridad prioridad,
            string tipouser, DateTime fechaInicio, DateTime fechaFin)
        {
            ID = id;
            LibroID = libroID;
            NombreUsuario = nombreuser;
            Prioridad = prioridad;
            FechaSolicitud = DateTime.Now;
            FechaInicio = fechaInicio;
            FechaFin = fechaFin;
            TipoUsuario = tipouser;
            Siguiente = null;
        }

        // Constructor adicional para cargar desde archivo
        public Reserva(int id, int libroID, string nombreUsuario, 
            TipoPrioridad prioridad, string tipoUsuario, DateTime fechaSolicitud
            )
        {
            ID = id;
            LibroID = libroID;
            NombreUsuario = nombreUsuario;
            Prioridad = prioridad;
            FechaSolicitud = fechaSolicitud;            
            TipoUsuario = tipoUsuario;
            Siguiente = null;
        }

        //Define los niveles de prioridad:
        public enum TipoPrioridad
        {
            Alta = 0,   //profesores, personal academico
            Media = 1,  // estudiantes posgrado
            Baja = 2    // estudiantes pregrado
        }

        
    }
}
