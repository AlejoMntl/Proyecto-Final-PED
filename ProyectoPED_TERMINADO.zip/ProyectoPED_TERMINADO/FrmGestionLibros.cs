﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoPED_1
{
   
    public partial class FrmGestionLibros : MetroFramework.Forms.MetroForm
	{
        //referencia al formualrio principal para regresar al mismo
        private FrmMenu menu;

		//referencia de la clase de la ListaEnlazada
		private ListaEnlazada enlazada = new ListaEnlazada();


		//Constructor que recibe la referencia del menu principal
		public FrmGestionLibros(FrmMenu Menu)
        {
            InitializeComponent();
            menu = Menu; //agina el formulario del menu principal al atributo de clase

            enlazada = new ListaEnlazada();
            ConfigurarDataGridView();//crea las columnas al iniciar el programa


            ActualizarDGV();

		}

        private void ConfigurarDataGridView()
        {
            // Configurar columnas del DataGridView
           DGVLibros.AutoGenerateColumns = false;

            //configura la columna del ID
            DGVLibros.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ID",
                HeaderText = "ID",
                DataPropertyName = "ID"
            });

            //configura la columna del titulo
            DGVLibros.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Titulo",
                HeaderText = "Título",
                DataPropertyName = "Titulo",
                Width = 200
            });

            //configura la columna del autor
           DGVLibros.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Autor",
                HeaderText = "Autor",
                DataPropertyName = "Autor",
                Width = 150
            });

            //configuracion para la columna de la fecha, dandole un formato
            DGVLibros.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "AñoPublicacion",
                HeaderText = "Año de Publicacion",
                DataPropertyName = "añoPublicacion"
            });

            //configuracion para la columna para verificar si esta disponible
            DataGridViewCheckBoxColumn colDisponible = new DataGridViewCheckBoxColumn();
            colDisponible.Name = "DisponibleParaReserva";
            colDisponible.HeaderText = "Disponible";
            colDisponible.DataPropertyName = "DisponibleParaReserva"; 
            DGVLibros.Columns.Add(colDisponible);

        }


        private void ActualizarDGV()
        {
            //obtiene los libros y los muestra en el dgv
            var libros = enlazada.ObtenerLibros();
            DGVLibros.DataSource = null;
            DGVLibros.DataSource = enlazada.ObtenerLibros();
			DGVLibros.Refresh();
		}

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            menu.Show(); //muestra el formulario del menu principal
            this.Close(); //cierra el form actual
        }

        private void FrmGestionLibros_Load(object sender, EventArgs e)
        {
            DGVLibros.AutoGenerateColumns = false; //evita que se generen columnas automaticamente
			ActualizarDGV();
		}
            
        private void btnAgregarLibro_Click(object sender, EventArgs e)
        {
            try
            {
                string autor = txtAutor.Text;
                string titulo = txtTitulo.Text;               
                bool disponible = chkDisponible.Checked;



                if(string.IsNullOrWhiteSpace(autor) || string.IsNullOrWhiteSpace(titulo))
                {
                    MessageBox.Show("Por favor, complete los campos de autor y titulo",
                        "Datos incompletos", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }
                if(!int.TryParse(txtAñoPublicado.Text, out int añoPublicacion))
                {
                    MessageBox.Show("Por favor ingrese un año valido", "Año Invalido",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                
                enlazada.AgregarLibro(autor, titulo,añoPublicacion, disponible);
                ActualizarDGV();
                LimpiarCampos();


				// Guardar automáticamente en el archivo TXT
				enlazada.GuardarEnArchivo();

				MessageBox.Show("Libro agregado correctamente", "Exito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Error al agregar libro: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            LimpiarCampos();
        }

       
       

        private void LimpiarCampos()
        {
           
            txtAutor.Text = "";
            txtTitulo.Text = "";
            txtAñoPublicado.Text = DateTime.Now.Year.ToString();
            chkDisponible.Checked = true;
        }

        private void btnConsultarLibros_Click(object sender, EventArgs e)
        {
			var consulta = new ConsultaLibros(this);
			consulta.FormClosed += (s, args) => {
				this.Show();
				ActualizarDGV(); // Al regresar de consulta libro actualiza el grid por si hubo algun cambio
			};
			this.Hide();
            consulta.Show();
        }


		private void btnGuardarDatos_Click(object sender, EventArgs e)
		{
			try
			{
				enlazada.GuardarEnArchivo();
				MessageBox.Show("Todos los libros han sido guardados en libros.txt",
							  "Datos Guardados",
							  MessageBoxButtons.OK,
							  MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error al guardar los datos: {ex.Message}",
							  "Error",
							  MessageBoxButtons.OK,
							  MessageBoxIcon.Error);
			}
		}

		internal ListaEnlazada ObtenerListaEnlazada()
		{
			return this.enlazada;
		}
	}
}
